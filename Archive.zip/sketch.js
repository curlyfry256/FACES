var mic; //SETS UP A VARIABLE FOR THE MICROPHONE
var person = "face" //RECOGNISES THE WORD "FACE" UNDER THE PERSON VARIABLE
var state = 0; // SETS THE STATE AUTOMATICALLY TO 0 UNLESS TOLD OTHERWISE
var url = 'https://cors-anywhere.herokuapp.com/https://pixabay.com/api/?&key=12140127-53947c0bce33919a78a22cdd9&per_page=5&q=';
var link = ["https://cors-anywhere.herokuapp.com/https://pixabay.com/get/ed35b8082df7063ed1584d05fb1d4794e273e2d41bb60c4090f5c571a7e9b3bede_1280.jpg"];
var Image; //SETS UP A VARIABLE FOR THE IMAGE
var searchurl //SETS UP A VARIABLE FOR SEARCH-URL

function preload() {
  var button = select('#submit'); //SETS UP SUBMIT SEARCH
  button.mousePressed(loadCat); //WHEN SUBMIT BUTTON IS PRESSED LOAD IMAGE
  var button = select('#show'); //SETS UP SHOW IMAGE
  button.mousePressed(loadCat); //WHEN  SHOW IMAGE BUTTON IS PRESSED LOAD IMAGE
}

function setup(){
    mic = new p5.AudioIn()
    mic.start(); //STARTS THE MICROPHONE INPUT
    createCanvas (600,1500); //MAKES A CANVAS 600/600 PIXELS
    input = select('#search');
    loadCat();
}

function loadCat() {
  searchurl = url + input.value();
  loadJSON(searchurl, gotData);
  Image = loadImage(link[0]); //setTimeout(setupAPI, 4000

}

function gotData(data) {
    link.unshift("https://cors-anywhere.herokuapp.com/" + data.hits[0].largeImageURL); // data into global variable
    console.log(data);
}

function draw(){

    micLevel = mic.getLevel();
    micLevel = (micLevel*100)// SETS MIC LEVEL TO 500
    background(255); // SETS BACKGROUND TO WHITE

    image(Image, 0, 0);


    if (state == 0){ // IF STATE IS 0 THEN RUN FACE
            face(); //LABELLNG AS FACE
        }
    if (state == 1){ // IF STATE IS 1 THEN RUN GIRL
            boy(); //LABELLING AS LION
        }
    if (state == 2){ //IF STATE IS 2 THEN RUN BOY
            kid();// LABELLING AS PANTHER
        }




    //FACE DRAWING




}

function keyPressed() {



  if (keyCode === ENTER) { //WHEN ENTER IS PRESSED TH IMAGE WILL CHANGE
  
   switch(state) {  //COMPARE THE VALUE OF STATE AGAINST:
    case 0:   //IF STATE HAS A VALUE OF 0 THEN CHANGE THE VALUE STATE TO 1
        state = 1;
        break; //LEAVES TO MOVE TO NEXT SWITCH*
    case 1: //IF STATE HAS A VALUE OF 1 THEN CHANGE THE VALUE STATE TO 2
        state = 2;
        break;//*
    case 2://IF STATE HAS A VALUE OF 2 THEN CHANGE THE VALUE STATE TO 0
        state = 0;
        break;//*

    default: //IN THE CASE OF ERROR WHERE STATE IS NOT EQUAL TO 0, 1 OR 2 RESET STATE TO 0
        {
          state = 0; //INPUT CAN BE ANY OF THE STATES, IT IS 0 BECAUSE THAT IS THE FIRST STATE
        }
}

   }
  }


function mirrorLine(x1, y1, x2,y2) { //THIS MIRROS THE LEFT SIDE OF THE FACE

    line(x1, y1, x2, y2) // THIS CALLS THE AXIS
    line(width - x1 , y1, width - x2 ,y2) //THIS CALLS WHERE TO PLOT EACH CORDINATE




}
    function face(){

    strokeWeight(4); //SETS THE LINE THICKNESS TO 4
    mirrorLine(300, 170, 360, 370) //OUTER NOSE LINE
    mirrorLine(300, 170, 320, 360) //INNER NOSE LINE
    mirrorLine(320, 360, 300, 360) //MIDDLE NOSE RIDGE
    mirrorLine(320, 360, 300, 380) //INNER NOSE
    mirrorLine(360, 370, 380, 460) //NOSE TO OUTER LIP
    mirrorLine(360, 370, 300, 380) //UNDER NOSE
    mirrorLine(360, 370, 330, 420) //NOSE TO LIP LINE
    mirrorLine(230, 230, 240, 370) //EYE TO OUTER NOSE
    mirrorLine(240, 370, 130, 340) // CHEEK DENT
    mirrorLine(200, 230, 130, 340) //OUTER CHEEK
    mirrorLine(140, 190, 130, 340) //OUTER EYE TO CHEEK
    mirrorLine(130, 340, 220, 460) //CHEEK TO OUTER MOUTH
    mirrorLine(360, 370, 320, 360) //OUTER NOSE RIDGE
    mirrorLine(380, 460, 340, 500) //OUTER CHIN
    mirrorLine(130, 340, 160, 450) //UPPER JAW
    mirrorLine(160, 450, 260, 500) //LOWER JAW
    mirrorLine(130, 340, 120, 140) //OUTER HEAD
    mirrorLine(120, 140 ,130, 100) //UPPER HEAD
    mirrorLine(130, 100, 150, 60)  //OUTER UPPER HEAD
    mirrorLine(150, 60, 300, 60) //TOP HEAD

    strokeWeight(6); //SETS THE LINE THICKNESS TO 6 (MOUTH)
    mirrorLine(330, 420, 300, 420) // UPPER LIP
    mirrorLine(330, 420, 380, 460) //OUTER LIP
    mirrorLine(380, 460, 300, 460 + micLevel*30) // LOWER LIP

    mirrorLine(150,140, 210, 130 - micLevel*30) //LEFT EYEBROW
    mirrorLine(210, 130 - micLevel*30, 250, 140) // RIGHT EYEBROW



    mirrorLine(150, 150, 140, 190); //LEFT EYE
    mirrorLine(150, 150, 230, 150); //TOP EYE
    mirrorLine(230, 150, 300, 170); //UPPER INNER EYE
    mirrorLine(140, 190, 200, 230); //LOWER LEFT EYE
    mirrorLine(230, 230, 300, 170) //LOWER INNER EYE
    mirrorLine(200, 230, 230, 230) // UNDER EYE



  




    }



    function boy(){

strokeWeight(4);
    mirrorLine(150, 60, 300, 60); // TOP HEAD
    mirrorLine(150, 60, 150, 280); //SIDE HEAD
    mirrorLine(150, 150, 130, 140); //TOP EAR
    mirrorLine(130, 140, 110, 190); //OUTER EAR
    mirrorLine(110, 190, 130, 250); //OUTER LOWER EAR
    mirrorLine(130, 250, 135, 250); //LOWER EAR
    mirrorLine(135, 250, 150, 280); //INNER LOWER EAR
    mirrorLine(150, 280, 270, 420); //JAW
    mirrorLine(150, 150, 180, 180); //EAR TO EYE
    mirrorLine(180, 180, 150, 280); //EYE TO LOWER EAR
    mirrorLine(280, 180, 285, 250); //NOSE RIDGE
    mirrorLine(285, 250, 270, 270); //OUTER NOSE
    mirrorLine(270, 270, 300, 280); //INNER NOSE
    mirrorLine(230, 210, 270, 270); //EYE TO NOSE
    mirrorLine(150, 280, 270, 270); //LOWER EAR TO NOSE


strokeWeight(6);
    mirrorLine(180, 180, 230, 150); //UPPER OUTER EYE
    mirrorLine(180, 180, 230, 210); //LOWER OUTER EYE
    mirrorLine(230, 210, 280, 180); //LOWER INNER EYE
    mirrorLine(230, 150, 280, 180); //UPPER INNER EYE
    mirrorLine(180, 150 - micLevel*30, 220, 130); //LEFT EYEBROW
    mirrorLine(220, 130, 250, 150 - micLevel*30); //RIGHT EYEBROW
    mirrorLine(270, 420, 300, 400); //UPPER BEARD
    mirrorLine(270, 420, 300, 450); //LOWER BEARD


strokeWeight(8);
    mirrorLine(230, 290, 250, 300); //OUTER MOUTH
    mirrorLine(250, 300, 260, 290); //MIDDLE MOUTH
    mirrorLine(260, 290, 300, 300); //INNER MOUTH
    mirrorLine(260, 290, 300, 370 + micLevel*30); //LOWER MOUTH



}

    function kid(){

strokeWeight(4);
    mirrorLine(150, 60, 300, 60); //TOP HEAD
    mirrorLine(150, 60, 130, 120); //TOP SIDE HEAD
    mirrorLine(130, 120, 130, 350); //SIDE HEAD
    mirrorLine(130, 350, 150, 420); //JAW
    mirrorLine(150, 420, 300, 500); //CHIN
    mirrorLine(290, 270, 300, 270); //MIDDLE NOSE
    mirrorLine(290, 270, 285, 360); //LOWER NOSE CONNECTOR
    mirrorLine(285, 360, 300, 360); //LOWER NOSE HORIZONTAL
    mirrorLine(290, 270, 285, 220); //UPPER NOSE CONNECTOR
    mirrorLine(285, 220, 300, 220); //UPPER NOSE HORIZONTAL
    mirrorLine(210, 230, 130, 250); //EYE TO HEAD
    mirrorLine(210, 230, 130, 350); //EYE TO UPPER JAW
    mirrorLine(130, 350, 290, 270); //UPPER JAW TO MIDDLE NOSE
    mirrorLine(290, 270, 270, 350); //OUTER NOSE
    mirrorLine(270, 350, 285, 360); //OUTER NOSTRIL
    mirrorLine(285, 360, 270, 375); //NOSE TO UPPER LIP
    mirrorLine(250, 375, 300, 375); //UPPER LIP
    mirrorLine(250, 375, 240, 385); //UPPER OUTER LIP
    mirrorLine(240, 385, 300, 385); //TEETH
    mirrorLine(150, 420, 240, 385); //TEETH TO UPPER CHIN
    mirrorLine(130, 350, 240, 385); //TEETH TO LOWER HEAD
    mirrorLine(240, 385, 290, 270); //TEETH TO MIDDLE NOSE



strokeWeight(6);
    mirrorLine(285, 220, 230, 180- micLevel*5); //NOSE TO EYE
    mirrorLine(230, 180- micLevel*5, 210, 230); //OUTER UPPER EYE
    mirrorLine(210, 230, 230, 250+ micLevel*5); //OUTER LOWER EYE
    mirrorLine(230, 250 + micLevel*5, 285, 220); //INNER LOWER EYE
    mirrorLine(240, 385, 300, 430+ micLevel*5); //LOWER LIP
    mirrorLine(180, 150, 220, 130- micLevel*5); //LEFT EYEBROW
    mirrorLine(220, 130- micLevel*5, 250, 150); //RIGHT EYEBROW















    }
